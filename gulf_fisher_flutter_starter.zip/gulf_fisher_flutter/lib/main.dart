import 'package:flutter/material.dart';

void main() => runApp(const GulfFisherApp());

class GulfFisherApp extends StatelessWidget {
  const GulfFisherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'صياد الخليج',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF087E8B),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF071B2A),
        fontFamily: 'Roboto',
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('صياد الخليج', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('GULF FISHER', style: TextStyle(fontSize: 10, letterSpacing: 2)),
            ],
          ),
          backgroundColor: const Color(0xFF0B2A3D),
          actions: const [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Icon(Icons.satellite_alt, color: Colors.lightGreenAccent),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const _StatusPanel(),
            const SizedBox(height: 16),
            const _MapPlaceholder(),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.65,
              children: const [
                _FeatureTile(Icons.my_location, 'موقعي GPS', 'تحديد الموقع'),
                _FeatureTile(Icons.route, 'المسارات', 'رسم وتسجيل الرحلات'),
                _FeatureTile(Icons.waves, 'الأعماق البحرية', 'خرائط وقياسات موثوقة'),
                _FeatureTile(Icons.cloud, 'الطقس البحري', 'رياح وأمواج ومد وجزر'),
                _FeatureTile(Icons.pin_drop, 'مواقع الصيد', 'حفظ الإحداثيات'),
                _FeatureTile(Icons.warning_amber, 'المناطق المقيدة', 'حدود وتنبيهات رسمية'),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              'تنبيه ملاحي: هذه نسخة أولية للواجهة فقط. لا تستخدمها لتوجيه القارب أو لتحديد مناطق السماح والمنع قبل ربطها ببيانات بحرية رسمية والتحقق منها.',
              style: TextStyle(color: Colors.amber, height: 1.5, fontSize: 12),
            ),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          backgroundColor: const Color(0xFF0B2A3D),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.map), label: 'الخريطة'),
            NavigationDestination(icon: Icon(Icons.bookmark), label: 'المحفوظات'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'الإعدادات'),
          ],
          selectedIndex: 0,
        ),
      ),
    );
  }
}

class _StatusPanel extends StatelessWidget {
  const _StatusPanel();

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF10364A),
      child: const Padding(
        padding: EdgeInsets.all(14),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _StatusItem('GPS', 'غير متصل', Icons.gps_not_fixed),
            _StatusItem('الطقس', 'بانتظار البيانات', Icons.cloud_outlined),
            _StatusItem('الخرائط', 'غير محمّلة', Icons.download_for_offline),
          ],
        ),
      ),
    );
  }
}

class _StatusItem extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const _StatusItem(this.title, this.value, this.icon);

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Icon(icon, color: Colors.cyanAccent),
      const SizedBox(height: 6),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(value, style: const TextStyle(fontSize: 10, color: Colors.white70)),
    ],
  );
}

class _MapPlaceholder extends StatelessWidget {
  const _MapPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 230,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.cyanAccent.withOpacity(.35)),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF164C5C), Color(0xFF082638), Color(0xFF0B3445)],
        ),
      ),
      child: Stack(
        children: [
          const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.map_outlined, size: 48, color: Colors.cyanAccent),
                SizedBox(height: 8),
                Text('مساحة الخريطة البحرية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('سيتم ربط الخرائط البحرية المعتمدة هنا', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          Positioned(
            right: 12, top: 12,
            child: Chip(label: Text('وضع تجريبي', style: TextStyle(fontSize: 10))),
          ),
          const Positioned(
            left: 14, bottom: 12,
            child: Text('WGS84  •  عمق غير متاح', style: TextStyle(fontSize: 10, color: Colors.white70)),
          ),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _FeatureTile(this.icon, this.title, this.subtitle);

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF10364A),
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.cyanAccent, size: 26),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(subtitle, style: const TextStyle(fontSize: 10, color: Colors.white70)),
        ],
      ),
    ),
  );
}
